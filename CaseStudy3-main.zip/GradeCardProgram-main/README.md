# GradeCardProgram

# student.h is the header file
# student.c and main.c contain the code 
# makefile.mk contains the info on what to compile

# Code entirely written in Notepad, compiled with help of MingW64.
# mingw32-make -f makefile.mk --> use in Windows Command prompt to compile the code
# the output file is saved as grade_card_program.
# run it
